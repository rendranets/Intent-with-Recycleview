package com.dicoding.medicinal_plants.model;

public class Plant {
    private String name;
    private String latin_name;
    private String detail;
    private String detail2;

    public String getLatin_name() { return latin_name; }

    public void setLatin_name(String latin_name) {
        this.latin_name = latin_name;
    }

    public String getDetail2() {
        return detail2;
    }

    public void setDetail2(String detail2) {
        this.detail2 = detail2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    private int photo;
}
